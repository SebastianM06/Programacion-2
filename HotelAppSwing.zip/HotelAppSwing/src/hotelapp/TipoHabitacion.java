package hotelapp;

public enum TipoHabitacion {
    SIMPLE, DOBLE, SUITE
}